# Prepare real-provider acceptance

Run `pnpm acceptance:plan` to print the machine-readable plan. Use `node scripts/live-acceptance.mjs --output artifacts/P6/live-plan.json` to save it. Dry-run reads no auth or history and sends no network requests. `--execute` deliberately fails before any credential access. This delivery has no armed real transport adapter.

The proposed grant is at most 12 actual model dispatches, 120,000 estimated input tokens and 12,000 reserved output tokens. Nine dispatches cover the native summary and continuation first, remote summary and continuation, repeat remote and disk-restored continuation, source-to-text conversion, target native summarization and DeepSeek continuation. Three dispatches are a shared contingency. Every retry, fallback, extra slice and ordinary continuation consumes the same count. Additional scenarios remain pending if the cap is insufficient. No attempt expands the budget automatically.

The synthetic task and four scoring checks live in `scripts/live-acceptance.mjs`. Both sides must start with identical task and file bytes. Score facts, unfinished work, exact file state and tool results. A failed side is reported separately; no advantage percentage is valid without a completed native baseline and completed remote side.

Before future real execution, the coordinator needs a fresh explicit grant with expiry, exact provider/model/endpoint allowlist and budget. A reviewed transport-level adapter must reserve and durably fsync the shared ledger before each actual send, disable implicit SDK/provider retries, and stop before exceeding any cap. The included synthetic ledger tests exercise count, cancellation, persistence failure and redaction. They do not establish that a future real SDK integration cannot bypass a transport wrapper.

Only then may the existing Pi ModelRuntime resolve effective authorization. Dry-run describes `auth.json` or runtime authorization without opening it. Missing credentials go through the coordinator's secret tool. Tokens, headers, cookies and account identifiers must not enter reports. Synthetic sessions can contain opaque checkpoint data in a restricted raw evidence directory; public excerpts omit it.

Opaque traffic remains SSE only. WebSocket is unsupported. Real SSE reliability, summary quality, long-session behavior and provider migration are pending. The previous five-request authorization is exhausted and cannot be reused. Network duration is observed without an extension timeout. Token counts and zero fixture cost do not establish subscription fees.
